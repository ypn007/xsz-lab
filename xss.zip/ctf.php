<?php
setcookie('name', 'pentester');
$file = 'agent.txt';
$fp = fopen($file, 'a');
fwrite($fp, $_SERVER['HTTP_USER_AGENT'].'|');
fclose($fp);
if ($_SERVER['HTTP_USER_AGENT'] == "Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/91.0.4472.80 Mobile/15E148 Safari/604.1" & $_COOKIE['name'] == "Jeffrey Preston Bezos"){
echo "<center><h3>Congratulation<br><br><br>Flag : cyberbullet_nyimalay_ctf_5667988541<h3><center>";
exit();
}else{
header('HTTP/1.0 403 Forbidden');
echo "<center><h3>You Can't Access This File<br> If You Wanna Access This File.You Must Be A Iphone User And Must Be One Of The User  Of Chrome, Must Be Founder Of amazon.com.<br>You'd not Use Undate Products<h3><center>";
exit();
}
?>